from django.apps import AppConfig


class WcountConfig(AppConfig):
    name = 'wcount'
